var struct_s_c_b___type =
[
    [ "ADR", "struct_s_c_b___type.html#af084e1b2dad004a88668efea1dfe7fa1", null ],
    [ "AFSR", "struct_s_c_b___type.html#ab65372404ce64b0f0b35e2709429404e", null ],
    [ "AIRCR", "struct_s_c_b___type.html#ad3e5b8934c647eb1b7383c1894f01380", null ],
    [ "BFAR", "struct_s_c_b___type.html#a3f8e7e58be4e41c88dfa78f54589271c", null ],
    [ "CCR", "struct_s_c_b___type.html#a2d6653b0b70faac936046a02809b577f", null ],
    [ "CFSR", "struct_s_c_b___type.html#a0cda9e061b42373383418663092ad19a", null ],
    [ "CPACR", "struct_s_c_b___type.html#ac6a860c1b8d8154a1f00d99d23b67764", null ],
    [ "CPUID", "struct_s_c_b___type.html#a21e08d546d8b641bee298a459ea73e46", null ],
    [ "DFR", "struct_s_c_b___type.html#a85dd6fe77aab17e7ea89a52c59da6004", null ],
    [ "DFSR", "struct_s_c_b___type.html#a191579bde0d21ff51d30a714fd887033", null ],
    [ "HFSR", "struct_s_c_b___type.html#a14ad254659362b9752c69afe3fd80934", null ],
    [ "ICSR", "struct_s_c_b___type.html#a0ca18ef984d132c6bf4d9b61cd00f05a", null ],
    [ "ISAR", "struct_s_c_b___type.html#ae0136a2d2d3c45f016b2c449e92b2066", null ],
    [ "MMFAR", "struct_s_c_b___type.html#a2d03d0b7cec2254f39eb1c46c7445e80", null ],
    [ "MMFR", "struct_s_c_b___type.html#aa11887804412bda283cc85a83fdafa7c", null ],
    [ "PFR", "struct_s_c_b___type.html#a681c9d9e518b217976bef38c2423d83d", null ],
    [ "RESERVED0", "struct_s_c_b___type.html#ac89a5d9901e3748d22a7090bfca2bee6", null ],
    [ "SCR", "struct_s_c_b___type.html#a3a4840c6fa4d1ee75544f4032c88ec34", null ],
    [ "SHCSR", "struct_s_c_b___type.html#a7b5ae9741a99808043394c4743b635c4", null ],
    [ "SHP", "struct_s_c_b___type.html#a85768f4b3dbbc41fd760041ee1202162", null ],
    [ "VTOR", "struct_s_c_b___type.html#a187a4578e920544ed967f98020fb8170", null ]
];